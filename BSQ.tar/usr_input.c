/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   usr_input.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/09 00:40:39 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/10 06:05:08 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"
# define MALLOC_MAX 16711568

int		find_input_line_check(char *str)
{
	int len;
	int size;
	
	len = ft_strlen(str);
	if (len < 4)
		return (-1);
	else
	{	
		str[len - 4] = 0;
		size = ft_atoi(str);
		return (size);
	}
}

char	*usr_input_read(void)
{
	char	*buff;
	char	*save_buff;
	int		cur_pos;
	int		len;
	int		size;

	buff = char_malloc_set0(MALLOC_MAX);
	save_buff = char_malloc_set0(MALLOC_MAX);
	len = read(0, buff, MALLOC_MAX);
	ft_memcpy(save_buff, buff, len);
	cur_pos = len;
	size = find_input_line_check(buff);
	if	(size < 0)
		return (0);
	while (size-- > 0 && (len = read(0, buff, MALLOC_MAX)) > 0)
	{
		ft_memcpy(&save_buff[cur_pos], buff, len);
		cur_pos += len;
	}
	free(buff);
	buff = char_malloc_set0(ft_strlen(save_buff) + 1);
	ft_memcpy(buff, save_buff, ft_strlen(save_buff));
	free(save_buff);
	return (buff);
}
