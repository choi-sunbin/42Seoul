/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   valid_check.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/10 03:21:19 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/10 06:35:59 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int		valid_map_check(char **arr)
{
	int		loop;
	int		loop2;
	int		text_size;
	int		len;
	char	*charset;
	
	loop = 0;
	if ((len = first_line_check(arr[loop])) == -1)
		return (0);
	text_size = ft_strlen(arr[loop]);
	charset = (char*)malloc(sizeof(char) * text_size + 1);
	ft_memcpy(charset, &arr[loop][text_size - 3], 3);
	text_size = -1;
	loop = 0;
	while (++loop < len)
	{
		if (text_size == -1)
			text_size = ft_strlen(arr[loop]);
		if (text_size != ft_strlen(arr[loop]))
			return (0);
		loop2 = 0;
		while (loop2 < text_size)
			if (!(str_in_charset(arr[loop][loop2++], charset)))
				return (0);
	}
	return (1);
}

int		first_line_check(char *str)
{	
	int		loop;
	int		loop2;
	int		len;
	int		size;
	char	*temp;

	len = ft_strlen(str);
	if (len < 4)
		return (-1);
	temp = (char*)malloc(sizeof(char) * len + 10);
	ft_memcpy(temp, str, len - 3);
	size = ft_atoi(str);
	ft_memcpy(temp, &str[len - 3], 3);
	loop = 0;
	while (loop < 3)
	{
		loop2 = loop + 1;
		while (loop2 < 3)
			if (temp[loop] == temp[loop2++])
				return (-1);
		loop++;
	}
	free(temp);
	return (size);
}
