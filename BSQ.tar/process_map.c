/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:52:33 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/10 06:41:50 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

void set_g_value(char *first_str)
{
	int i;
	int j;
	char *num;
	
	g_max_x = 0;
	g_max_y = 0;
	g_max_len = 0;

	i = ft_strlen(first_str) - 1;
	g_fill = first_str[i--];
	g_not_available = first_str[i--];
	g_empty = first_str[i];

	num = malloc(sizeof(char) * i);
	j = 0;
	while (j < i)
	{
		num[j] = first_str[j];
		j++;
	}
	g_row = ft_atoi(num);
	free(num);
}

void	get_max(char **arr)
{
	int i;
	int j;
	int size;

	i = 1;
	size = 0;
	while (i < g_row +1)
	{
		j = 0;
		while (j < g_row)
		{
			size = get_rectangle_size(i, j, arr);
			if (size > g_max_len)
			{
				g_max_x = i;
				g_max_y = j;
				g_max_len = size;
			}
			j++;
		}
		i++;
	}
}

void	set_arr(char **arr)
{
	int x;
	int y;
	int i;
	int j;

	x = g_max_x;
	y = g_max_y;
	i = 0;
	j = 0;
	while (i <= g_max_len)
	{
		j = 0;
		while (j <= g_max_len)
		{
			arr[x + i][y + j] = g_fill;
			j++;
		}
		i++;
	}
}

char	**load_map(char *file)
{
	char	*file_str;
	char	**arr;

	file_str = read_file(file);
	arr = ft_split(file_str, "\n");
	return (arr);
}

void	process_map(char **arr)
{
	int loop;
	int len;

	if (valid_map_check(arr) == 0)
	{
		write(1, "map error\n", 10);
		return ;
	}
	set_g_value(arr[0]);
	get_max(arr);
	set_arr(arr);
	loop = 1;
	len = ft_strlen(arr[loop]);
	while(loop <= g_row)
	{
		write(1, arr[loop], len);
		write(1, "\n", 1);
		loop++;
	}
}
