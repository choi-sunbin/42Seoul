/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   file_util.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/10 05:23:47 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/10 05:23:53 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */


#include "bsq.h"

int		file_len(char *file)
{
	int		fd;
	char	c;
	int		len;

	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (-1);
	else
	{
		len = 0;
		while (read(fd, &c, 1))
			len++;
		close(fd);
	}
	len += 1;
	return (len);
}

char	*read_file(char *file)
{
	int		fd;
	int		len;
	char	*file_str;

	len = file_len(file);
	file_str = (char *)malloc(sizeof(char) * len);
	if (!file_str)
		return (0);
	fd = open(file, O_RDONLY);
	if (fd == -1)
		return (0);
	else
	{
		read(fd, file_str, len);
		close(fd);
	}
	file_str[len - 1] = 0;
	return (file_str);
}
