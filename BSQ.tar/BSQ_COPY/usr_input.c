/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   usr_input.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/09 00:40:39 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/09 11:04:59 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"
# define MALLOC_MAX 16711568

char	*usr_input_read(void)
{

	char				*read_buff;
	char				*save_buff;
	char				*str;
	unsigned int		cur_pos;
	unsigned int		len;

	read_buff = char_malloc_set0(MALLOC_MAX);
	save_buff = char_malloc_set0(MALLOC_MAX);
	cur_pos = 0;
	while ((len = read(0, read_buff, MALLOC_MAX)) > 0)
	{
		ft_memcpy(&save_buff[cur_pos], read_buff, len);
		cur_pos += len;
		if (cur_pos > MALLOC_MAX)
			return (0);
	}
	len = ft_strlen(save_buff);
	if ((str = char_malloc_set0(len + 1)) == 0)
		return (0);
	ft_memcpy(str, save_buff, len);
	str[len] = 0;
	free(read_buff);
	free(save_buff);
	return (str);
}
