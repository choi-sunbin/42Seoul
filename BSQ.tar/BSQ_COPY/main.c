/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:27:01 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/09 01:05:44 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

#define MALLOC_MAX 16711568

int main(int argc, char **argv)
{
	int 	loop;
	char	*usr_input;

	loop = 1;
	if (argc == 1)
	{
		usr_input = usr_input_read();
		printf("\nUSER INPUT!\n");
		printf("%s", usr_input);
	//	load_map(usr_input);
	//	free(usr_input);
	}
	if (argc > 1)
	{
		loop = 1;
		while(loop < argc)
		{
			load_map(argv[loop]);
			loop++;
		}
	}
}
