/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   memory_util.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/09 10:14:38 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/09 11:04:32 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

char	*char_malloc_set0(int size)
{
	char	*str;
	int		loop;

	str = (char*)malloc(sizeof(char) * size);
	loop = 0;
	while (loop < size)
		str[loop++] = 0;
	return (str);
}

void	ft_memcpy(char *dest, char *src, unsigned int size)
{
	unsigned int loop;
		
	loop = 0;
	while (loop < size)
	{
		dest[loop] = src[loop];
		loop++;
	}
}
