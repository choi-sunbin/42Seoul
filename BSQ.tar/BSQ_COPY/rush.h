/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush.h                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 12:37:58 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/09 10:52:00 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>

#ifndef RUSH_H
# define RUSH_H

int		g_row;
char	g_empty;
char	g_not_available;
char	g_fill;

int		g_max_x;
int		g_max_y;
int		g_max_len;

int		ft_strlen(char *str);
void	ft_putstr(char *str);
int		ft_strcmp(char *s1, char *s2);
char	*ft_strdup(char *src);
int		file_len(char *file);
char	*read_file(char *file);
char	**ft_split(char *str, char *charset);
void	load_map(char *file);
int		ft_atoi(char *str);
char	*usr_input_read(void);
char	*char_malloc_set0(int size);
void	ft_memcpy(char *dest, char *src, unsigned int size);

int	get_rectangle_size(int x, int y, char **map);
#endif
