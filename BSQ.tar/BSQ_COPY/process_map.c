/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   process_map.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:52:33 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/09 02:43:21 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "rush.h"

void set_g_value(char *first_str)
{
	int i;
	int j;
	char *num;
	
	g_max_x = 0;
	g_max_y = 0;
	g_max_len = 0;

	i = ft_strlen(first_str) - 1;
	g_fill = first_str[i--];
	g_not_available = first_str[i--];
	g_empty = first_str[i];

	num = malloc(sizeof(char) * i);
	j = 0;
	while (j < i)
	{
		num[j] = first_str[j];
		j++;
	}
	g_row = ft_atoi(num);
	free(num);
}

void	get_max(char **arr)
{
	int i;
	int j;
	int size;

	i = 1;
	size = 0;
	while (i < g_row +1)
	{
		j = 0;
		while (j < g_row)
		{
			size = get_rectangle_size(i, j, arr);
			if (size > g_max_len)
			{
				g_max_x = i;
				g_max_y = j;
				g_max_len = size;
			}
			j++;
		}
		i++;
	}
}

void	set_arr(char **arr)
{
	int x;
	int y;
	int i;
	int j;

	x = g_max_x;
	y = g_max_y;
	i = 0;
	j = 0;
	while (i <= g_max_len)
	{
		j = 0;
		while (j <= g_max_len)
		{
			arr[x + i][y + j] = g_fill;
			j++;
		}
		i++;
	}
}

void load_map(char *file)
{
	char	*file_str;
	char	**arr;
	int		loop;
	int		max_loop;

	file_str = read_file(file);
	arr = ft_split(file_str, "\n");

	set_g_value(arr[0]);
	get_max(arr);
	set_arr(arr);

	printf("%s", file_str);
	loop = 0;
	while(loop <= g_row)
	{
		printf("arr LOOP[%d] =%s\n", loop, arr[loop]);	
		loop++;
	}
	printf("check!");
}
