/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dfs.c                                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: nasong <nasong@student.42seoul.kr>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 13:53:12 by nasong            #+#    #+#             */
/*   Updated: 2020/12/10 05:19:15 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

int	is_available(int x, int y, int len, char **map)
{
	int i;
	int j;
	int k;

	i = x;
	j = y;
	k = 0;
	while (k <= len)
	{
		if(map[i][j-k] != g_empty)
			return (-1);
		if(map[i-k][j] != g_empty)
			return (-1);
		k++;
	}
	return (len);
}

int	get_rectangle_size(int x, int y, char **map)
{
	int i;
	int size;
	int result;

	i = 1;
	size = 0;
	result = 0;
	if (map[x][y] != g_empty)
		return (-1);
	while (x + i < g_row + 1  && y + i < g_row)
	{
		size = is_available(x+i, y+i, i, map);
		if (size == -1)
			break ;
		if (size > result)
			result = size;
		i++;
	}

	return (result);
}
