/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sunbchoi <sunbchoi@student.42seoul.kr      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/12/07 10:27:01 by sunbchoi          #+#    #+#             */
/*   Updated: 2020/12/10 06:10:10 by sunbchoi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "bsq.h"

#define MALLOC_MAX 16711568

int main(int argc, char **argv)
{
	int 	loop;
	char	*usr_input;
	char	**arr;
	
	loop = 1;
	if (argc == 1)
	{
		usr_input = usr_input_read();
		if (usr_input == 0)
			return (0);
		arr = ft_split(usr_input, "\n");	
		process_map(arr);
	}
	if (argc > 1)
	{
		loop = 1;
		while(loop < argc)
		{
			arr = load_map(argv[loop]);
			process_map(arr);
			loop++;
		}
	}
}
